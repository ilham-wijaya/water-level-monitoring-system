// ============================================================
// DASHBOARD MONITORING KETINGGIAN AIR
// Auto update tanpa refresh manual
// ============================================================

let waterChart = null;

// ============================================================
// AMBIL DATA DARI API
// ============================================================
async function fetchData() {
  try {
    const response = await fetch("/api/data?t=" + new Date().getTime(), {
      method: "GET",
      cache: "no-store"
    });

    if (!response.ok) {
      throw new Error("Gagal mengambil data dari /api/data");
    }

    const data = await response.json();
    return data;
  } catch (error) {
    console.error("Error fetchData:", error);
    return [];
  }
}

// ============================================================
// FORMAT ANGKA
// ============================================================
function formatNumber(value) {
  const number = parseFloat(value);

  if (isNaN(number)) {
    return "-";
  }

  return number.toFixed(2);
}

// ============================================================
// UPDATE KARTU DASHBOARD
// ============================================================
function updateCards(latestData) {
  if (!latestData) {
    document.getElementById("jarakSensor").textContent = "- cm";
    document.getElementById("tinggiAir").textContent = "- cm";
    document.getElementById("statusWarning").textContent = "-";
    document.getElementById("kondisiHujan").textContent = "-";
    document.getElementById("nilaiAO").textContent = "-";
    document.getElementById("waktuUpdate").textContent = "-";
    return;
  }

  document.getElementById("jarakSensor").textContent =
    `${formatNumber(latestData.jarak_sensor)} cm`;

  document.getElementById("tinggiAir").textContent =
    `${formatNumber(latestData.tinggi_air)} cm`;

  document.getElementById("statusWarning").textContent =
    latestData.status || "-";

  document.getElementById("kondisiHujan").textContent =
    latestData.kondisi_hujan || "-";

  document.getElementById("nilaiAO").textContent =
    latestData.nilai_hujan || "-";

  document.getElementById("waktuUpdate").textContent =
    latestData.waktu || "-";

  updateStatusColor(latestData.status);
}

// ============================================================
// UPDATE WARNA STATUS
// ============================================================
function updateStatusColor(status) {
  const statusCard = document.querySelector(".status-card");

  if (!statusCard) {
    return;
  }

  statusCard.classList.remove("normal", "waspada", "siaga");

  const statusUpper = String(status).toUpperCase();

  if (statusUpper === "NORMAL") {
    statusCard.classList.add("normal");
  } else if (statusUpper === "WASPADA") {
    statusCard.classList.add("waspada");
  } else if (statusUpper === "SIAGA") {
    statusCard.classList.add("siaga");
  }
}

// ============================================================
// UPDATE TABEL
// ============================================================
function updateTable(data) {
  const tableBody = document.getElementById("dataTable");

  if (!tableBody) {
    return;
  }

  tableBody.innerHTML = "";

  if (!data || data.length === 0) {
    tableBody.innerHTML = `
      <tr>
        <td colspan="6">Belum ada data</td>
      </tr>
    `;
    return;
  }

  const reversedData = [...data].reverse();

  reversedData.forEach((item) => {
    const status = String(item.status || "-").toUpperCase();

    let statusClass = "";
    if (status === "NORMAL") {
      statusClass = "status-normal";
    } else if (status === "WASPADA") {
      statusClass = "status-waspada";
    } else if (status === "SIAGA") {
      statusClass = "status-siaga";
    }

    const row = document.createElement("tr");

    row.innerHTML = `
      <td>${item.waktu || "-"}</td>
      <td>${formatNumber(item.jarak_sensor)} cm</td>
      <td>${formatNumber(item.tinggi_air)} cm</td>
      <td><span class="status-badge ${statusClass}">${item.status || "-"}</span></td>
      <td>${item.nilai_hujan || "-"}</td>
      <td>${item.kondisi_hujan || "-"}</td>
    `;

    tableBody.appendChild(row);
  });
}

// ============================================================
// UPDATE GRAFIK
// ============================================================
function updateChart(data) {
  const canvas = document.getElementById("waterChart");

  if (!canvas) {
    return;
  }

  if (!data || data.length === 0) {
    return;
  }

  const recentData = data.slice(-15);

  const labels = recentData.map((item) => {
    if (!item.waktu) {
      return "-";
    }

    const parts = item.waktu.split(" ");
    return parts.length > 1 ? parts[1] : item.waktu;
  });

  const tinggiAirData = recentData.map((item) => {
    const value = parseFloat(item.tinggi_air);
    return isNaN(value) ? 0 : value;
  });

  if (waterChart) {
    waterChart.data.labels = labels;
    waterChart.data.datasets[0].data = tinggiAirData;
    waterChart.update();
    return;
  }

  waterChart = new Chart(canvas, {
    type: "line",
    data: {
      labels: labels,
      datasets: [
        {
          label: "Estimasi Ketinggian Air (cm)",
          data: tinggiAirData,
          borderWidth: 2,
          tension: 0.35,
          fill: true,
          pointRadius: 4,
          pointHoverRadius: 6
        }
      ]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      animation: false,
      scales: {
        x: {
          title: {
            display: true,
            text: "Waktu"
          }
        },
        y: {
          beginAtZero: true,
          suggestedMax: 50,
          title: {
            display: true,
            text: "Ketinggian Air (cm)"
          }
        }
      },
      plugins: {
        legend: {
          display: true
        }
      }
    }
  });
}

// ============================================================
// LOAD SEMUA DATA KE DASHBOARD
// ============================================================
async function loadData() {
  const data = await fetchData();

  if (!data || data.length === 0) {
    updateCards(null);
    updateTable([]);
    return;
  }

  const latestData = data[data.length - 1];

  updateCards(latestData);
  updateTable(data);
  updateChart(data);
}

// ============================================================
// TAMBAH DATA SIMULASI
// Dipanggil dari tombol index.html:
// onclick="simulateData()"
// ============================================================
async function simulateData() {
  try {
    const response = await fetch("/api/add?t=" + new Date().getTime(), {
      method: "POST",
      cache: "no-store"
    });

    if (!response.ok) {
      throw new Error("Gagal menambahkan data simulasi");
    }

    const result = await response.json();

    console.log("Hasil tambah data:", result);

    // Langsung update dashboard setelah data ditambahkan
    await loadData();

  } catch (error) {
    console.error("Error simulateData:", error);
    alert("Gagal menambahkan data simulasi. Cek terminal Flask.");
  }
}

// ============================================================
// JALANKAN AUTO UPDATE
// ============================================================
document.addEventListener("DOMContentLoaded", function () {
  console.log("Dashboard aktif. Auto update berjalan.");

  loadData();

  // Update otomatis setiap 2 detik
  setInterval(function () {
    loadData();
  }, 2000);
});