from flask import Flask, render_template, jsonify, send_file, request
from datetime import datetime
import csv
import os
import requests

app = Flask(__name__)

# ============================================================
# MATIKAN CACHE
# ============================================================
app.config["SEND_FILE_MAX_AGE_DEFAULT"] = 0


@app.after_request
def add_header(response):
    response.headers["Cache-Control"] = "no-store, no-cache, must-revalidate, max-age=0"
    response.headers["Pragma"] = "no-cache"
    response.headers["Expires"] = "0"
    return response


# ============================================================
# FILE CSV
# ============================================================
CSV_FILE = "data_sensor.csv"

CSV_HEADER = [
    "waktu",
    "jarak_sensor",
    "tinggi_air",
    "status",
    "nilai_hujan",
    "kondisi_hujan"
]


# ============================================================
# TELEGRAM CONFIG
# ============================================================
TELEGRAM_BOT_TOKEN = "8768295662:AAEClK-0pk6FBFffDMiU6x5fOIhZoeCVU-E"
TELEGRAM_CHAT_ID = "8308224358"


# ============================================================
# KONFIGURASI SISTEM
# ============================================================
BATAS_NORMAL = 15.0
BATAS_WASPADA = 25.0


# ============================================================
# FUNGSI CSV
# ============================================================
def init_csv():
    """
    Membuat file CSV jika belum ada atau masih kosong.
    Header wajib:
    waktu,jarak_sensor,tinggi_air,status,nilai_hujan,kondisi_hujan
    """
    if not os.path.exists(CSV_FILE) or os.path.getsize(CSV_FILE) == 0:
        with open(CSV_FILE, mode="w", newline="", encoding="utf-8") as file:
            writer = csv.writer(file)
            writer.writerow(CSV_HEADER)


def baca_semua_data():
    """
    Membaca semua data dari CSV.
    """
    init_csv()

    data = []

    with open(CSV_FILE, mode="r", newline="", encoding="utf-8") as file:
        reader = csv.DictReader(file)

        for row in reader:
            if not row.get("waktu"):
                continue

            data.append({
                "waktu": row.get("waktu", "-"),
                "jarak_sensor": row.get("jarak_sensor", "-"),
                "tinggi_air": row.get("tinggi_air", "-"),
                "status": row.get("status", "-"),
                "nilai_hujan": row.get("nilai_hujan", "-"),
                "kondisi_hujan": row.get("kondisi_hujan", "-")
            })

    return data


def baca_data_terakhir():
    """
    Membaca data terakhir dari CSV.
    """
    data = baca_semua_data()

    if len(data) == 0:
        return None

    return data[-1]


def tambah_data_csv(data):
    """
    Menambahkan satu baris data ke CSV.
    """
    init_csv()

    with open(CSV_FILE, mode="a", newline="", encoding="utf-8") as file:
        writer = csv.writer(file)
        writer.writerow([
            data["waktu"],
            data["jarak_sensor"],
            data["tinggi_air"],
            data["status"],
            data["nilai_hujan"],
            data["kondisi_hujan"]
        ])


# ============================================================
# FUNGSI STATUS
# ============================================================
def tentukan_status(tinggi_air):
    """
    Menentukan status warning berdasarkan tinggi air.
    """
    try:
        tinggi_air = float(tinggi_air)
    except:
        tinggi_air = 0.0

    if tinggi_air < BATAS_NORMAL:
        return "NORMAL"
    elif tinggi_air < BATAS_WASPADA:
        return "WASPADA"
    else:
        return "SIAGA"


def tentukan_kondisi_hujan(nilai_hujan):
    """
    Menentukan kondisi hujan berdasarkan nilai analog YL-83.
    Pada banyak modul:
    nilai kecil = basah
    nilai besar = kering
    """
    try:
        nilai_hujan = int(nilai_hujan)
    except:
        nilai_hujan = 4095

    if nilai_hujan < 2000:
        return "HUJAN"
    else:
        return "TIDAK HUJAN"


# ============================================================
# TELEGRAM
# ============================================================
def kirim_telegram(data):
    """
    Mengirim notifikasi Telegram saat status WASPADA atau SIAGA.
    """
    pesan = (
        "🚨 WARNING SYSTEM KETINGGIAN AIR 🚨\n\n"
        f"Status: {data['status']}\n"
        f"Jarak sensor ke permukaan air: {data['jarak_sensor']} cm\n"
        f"Estimasi ketinggian air: {data['tinggi_air']} cm\n"
        f"Kondisi hujan: {data['kondisi_hujan']}\n"
        f"Nilai AO hujan: {data['nilai_hujan']}\n"
        f"Waktu: {data['waktu']}\n\n"
        "Keterangan: Sistem menerima data asli dari ESP32."
    )

    url = f"https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}/sendMessage"

    try:
        response = requests.post(
            url,
            data={
                "chat_id": TELEGRAM_CHAT_ID,
                "text": pesan
            },
            timeout=10
        )

        if response.status_code == 200:
            print("Notifikasi Telegram berhasil dikirim.")
            return True
        else:
            print("Gagal mengirim Telegram:", response.text)
            return False

    except Exception as error:
        print("Error Telegram:", error)
        return False


# ============================================================
# PROSES DATA DARI ESP32
# ============================================================
def proses_data_esp32(payload):
    """
    Memproses payload JSON dari ESP32 menjadi format data CSV.
    ESP32 dapat mengirim:
    {
        "jarak_sensor": 39.07,
        "tinggi_air": 10.93,
        "status": "NORMAL",
        "nilai_hujan": 4095,
        "kondisi_hujan": "TIDAK HUJAN"
    }

    Jika status/kondisi_hujan tidak dikirim, server akan menghitungnya.
    """

    jarak_sensor = payload.get("jarak_sensor", 0)
    tinggi_air = payload.get("tinggi_air", 0)
    nilai_hujan = payload.get("nilai_hujan", 4095)

    try:
        jarak_sensor = round(float(jarak_sensor), 2)
    except:
        jarak_sensor = 0.0

    try:
        tinggi_air = round(float(tinggi_air), 2)
    except:
        tinggi_air = 0.0

    try:
        nilai_hujan = int(nilai_hujan)
    except:
        nilai_hujan = 4095

    status = payload.get("status")
    if not status:
        status = tentukan_status(tinggi_air)

    kondisi_hujan = payload.get("kondisi_hujan")
    if not kondisi_hujan:
        kondisi_hujan = tentukan_kondisi_hujan(nilai_hujan)

    data_baru = {
        "waktu": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "jarak_sensor": jarak_sensor,
        "tinggi_air": tinggi_air,
        "status": status,
        "nilai_hujan": nilai_hujan,
        "kondisi_hujan": kondisi_hujan
    }

    tambah_data_csv(data_baru)

    print("Data asli dari ESP32 diterima:", data_baru)

    if data_baru["status"] in ["WASPADA", "SIAGA"]:
        kirim_telegram(data_baru)

    return data_baru


# ============================================================
# ROUTE HALAMAN UTAMA
# ============================================================
@app.route("/")
def index():
    init_csv()
    return render_template("index.html")


# ============================================================
# ROUTE API DATA UNTUK DASHBOARD
# ============================================================
@app.route("/api/data", methods=["GET"])
def api_data():
    data = baca_semua_data()
    return jsonify(data)


@app.route("/api/latest", methods=["GET"])
def api_latest():
    latest = baca_data_terakhir()

    if latest is None:
        return jsonify({
            "waktu": "-",
            "jarak_sensor": "-",
            "tinggi_air": "-",
            "status": "-",
            "nilai_hujan": "-",
            "kondisi_hujan": "-"
        })

    return jsonify(latest)


# ============================================================
# ROUTE PENERIMA DATA ASLI DARI ESP32
# ============================================================
@app.route("/api/esp32", methods=["POST"])
def api_esp32():
    """
    Endpoint utama untuk menerima data asli dari ESP32.
    Gunakan URL ini di Arduino IDE:
    http://IP_LAPTOP:5000/api/esp32
    """

    try:
        payload = request.get_json(force=True)

        if not payload:
            return jsonify({
                "success": False,
                "message": "Data JSON kosong"
            }), 400

        data_baru = proses_data_esp32(payload)

        return jsonify({
            "success": True,
            "message": "Data dari ESP32 berhasil diterima",
            "data": data_baru
        })

    except Exception as error:
        print("Error menerima data dari ESP32:", error)

        return jsonify({
            "success": False,
            "message": "Gagal menerima data dari ESP32",
            "error": str(error)
        }), 400


@app.route("/api/sensor", methods=["POST"])
def api_sensor():
    """
    Endpoint alternatif.
    Ini dipertahankan agar kode lama yang mengirim ke /api/sensor tetap bisa jalan.
    """

    try:
        payload = request.get_json(force=True)

        if not payload:
            return jsonify({
                "success": False,
                "message": "Data JSON kosong"
            }), 400

        data_baru = proses_data_esp32(payload)

        return jsonify({
            "success": True,
            "message": "Data sensor asli berhasil diterima",
            "data": data_baru
        })

    except Exception as error:
        print("Error menerima data sensor:", error)

        return jsonify({
            "success": False,
            "message": "Gagal menerima data sensor",
            "error": str(error)
        }), 400


# ============================================================
# ROUTE DOWNLOAD CSV
# ============================================================
@app.route("/download")
def download_csv():
    init_csv()
    return send_file(
        CSV_FILE,
        as_attachment=True,
        download_name="data_sensor.csv"
    )


@app.route("/download-csv")
def download_csv_alt():
    init_csv()
    return send_file(
        CSV_FILE,
        as_attachment=True,
        download_name="data_sensor.csv"
    )


# ============================================================
# ROUTE STATUS DAN DEBUG
# ============================================================
@app.route("/status")
def status_server():
    data = baca_semua_data()

    return jsonify({
        "status": "Flask aktif",
        "mode": "DATA ASLI ESP32",
        "csv_file": CSV_FILE,
        "jumlah_data": len(data),
        "data_terakhir": data[-1] if len(data) > 0 else None
    })


@app.route("/debug/csv")
def debug_csv():
    csv_path = os.path.abspath(CSV_FILE)

    isi_file = []
    if os.path.exists(CSV_FILE):
        with open(CSV_FILE, mode="r", encoding="utf-8") as file:
            isi_file = file.readlines()

    return jsonify({
        "csv_file": CSV_FILE,
        "csv_path": csv_path,
        "file_exists": os.path.exists(CSV_FILE),
        "jumlah_baris_file": len(isi_file),
        "isi_file": isi_file
    })


# ============================================================
# MAIN PROGRAM
# ============================================================
if __name__ == "__main__":
    init_csv()

    app.run(
        host="0.0.0.0",
        port=5000,
        debug=True,
        use_reloader=False
    )